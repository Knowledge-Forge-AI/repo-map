"""Database initialization and backup plan execution."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from common_lore_index.ops.config import resolve_repo_map_home
from common_lore_index.runtime._backup_observation import (
    observe_database_provenance,
    verify_provenance_fingerprints,
)
from common_lore_index.runtime._backup_operations import (
    acquire_or_reuse_backup_maintenance_window,
    apply_source_schema,
    create_database,
    database_already_exists,
    database_exists,
    default_backup_runner,
    ensure_new_backup_directory,
    inspect_owned_postgres_container,
    run_pg_dump,
    run_pg_restore,
)
from common_lore_index.runtime._backup_provenance import EXTENSION_V2_RESTORE_PROTOCOL, observe_archive_toc
from common_lore_index.runtime._backup_support import (
    derive_manifest_support,
    quiescence_record_for_databases,
    require_backup_restore_supported,
)
from common_lore_index.runtime._extension_restore_lifecycle import execute_extension_v2_restore_set
from common_lore_index.runtime._extension_restore_policy import TrustedExtensionRestorePolicy
from common_lore_index.runtime._extension_restore_preflight import preflight_extension_v2_restore_set
from common_lore_index.runtime.backup_commands import (
    CommandRunner,
    backup_root,
    container_internal_enabled,
    planned_create_database_command,
    planned_pg_restore_command,
    read_runtime_password,
    safe_timestamp,
    timestamp_utc,
    validate_database_name,
)
from common_lore_index.runtime.backup_inspection import verify_archive_toc_for_restore
from common_lore_index.runtime.backup_manifests import (
    bounded_text,
    optional_manifest_text,
    read_manifest_file,
    resolve_backup_manifest_path,
    select_dump_file_for_database,
    verify_dump_file_checksum,
    write_manifest_and_restore_docs,
)
from common_lore_index.runtime.backup_records import (
    LocalDbBackupError,
    LocalDbBackupPlan,
    LocalDbBackupResult,
    LocalDbInitResult,
    RuntimeContainerMetadata,
)
from common_lore_index.runtime.backup_streaming import atomic_private_backup_directory
from common_lore_index.runtime._lexical_restore import reconcile_restored_graph_lexical_roles
from common_lore_index.runtime.database_roles import reconcile_graph_database_roles
from common_lore_index.runtime.local import (
    LocalRuntimeDiagnostic,
    LocalRuntimePlan,
    build_local_runtime_plan,
)
from common_lore_index.runtime.provisioning import complete_graph_provision


def validate_owned_database(
    database: str,
    plan: LocalRuntimePlan,
    *,
    graph_only: bool = False,
) -> None:
    """Require one exact configured graph or graph/control lifecycle target."""

    allowed = plan.graph_databases if graph_only else plan.owned_databases
    if database in allowed:
        return
    raise LocalDbBackupError(
        (
            LocalRuntimeDiagnostic(
                "error",
                "database-not-owned",
                "database",
                "database is not an authorized RepoMap lifecycle target",
            ),
        )
    )


def init_database_from_source(
    repo_map_home: str | Path | None,
    *,
    database: str,
    dry_run: bool = False,
    command_runner: CommandRunner | None = None,
) -> LocalDbInitResult:
    validate_database_name(database)
    runner = command_runner or default_backup_runner()
    home = resolve_repo_map_home(repo_map_home)
    runtime_plan = build_local_runtime_plan(home)
    validate_owned_database(database, runtime_plan, graph_only=True)
    inspect_fn = inspect_owned_postgres_container
    container = inspect_fn(runtime_plan, runner)
    exists_fn = database_exists
    existed = exists_fn(runtime_plan, database, runner)
    if existed:
        raise database_already_exists(database)
    planned = planned_create_database_command(runtime_plan)
    if dry_run:
        return LocalDbInitResult(
            command="init",
            result="dry_run",
            repo_map_home=home,
            database=database,
            source_mode="source",
            runtime_plan=runtime_plan,
            container=container,
            target_existed=False,
            planned_actions=("create-database", "apply-source-schema"),
            planned_command=planned,
        )
    create_fn = create_database
    create_fn(runtime_plan, database, runner)

    schema_fn = apply_source_schema
    roles_fn = reconcile_graph_database_roles

    def provision_from_source() -> None:
        schema_fn(runtime_plan, database, runner)
        roles_fn(runtime_plan, database, runner)

    complete_graph_provision(
        runtime_plan,
        database,
        runner,
        provision_from_source,
    )
    return LocalDbInitResult(
        command="init",
        result="success",
        repo_map_home=home,
        database=database,
        source_mode="source",
        runtime_plan=runtime_plan,
        container=container,
        target_existed=False,
        planned_actions=("create-database", "apply-source-schema"),
        planned_command=planned,
        database_created=True,
        schema_initialized=True,
        schema_ready=True,
    )


def init_database_from_dump(
    repo_map_home: str | Path | None,
    *,
    database: str,
    backup: str | Path,
    dry_run: bool = False,
    command_runner: CommandRunner | None = None,
    extension_restore_policy: TrustedExtensionRestorePolicy | None = None,
) -> LocalDbInitResult:
    validate_database_name(database)
    runner = command_runner or default_backup_runner()
    home = resolve_repo_map_home(repo_map_home)
    runtime_plan = build_local_runtime_plan(home)
    validate_owned_database(database, runtime_plan, graph_only=True)
    backups_root = backup_root(home)
    manifest_path = resolve_backup_manifest_path(backups_root, backup)
    manifest = read_manifest_file(manifest_path)
    dump_file = select_dump_file_for_database(manifest, database)
    dump_path = manifest_path.parent / dump_file["name"]
    verify_dump_file_checksum(dump_path, dump_file)
    evaluation = require_backup_restore_supported(
        manifest,
        database=database,
        require_quiescence=False,
        dry_run=dry_run,
        target=database,
        extension_restore_policy=extension_restore_policy,
    )
    inspect_fn = inspect_owned_postgres_container
    container = inspect_fn(runtime_plan, runner)
    if evaluation.restore_protocol == EXTENSION_V2_RESTORE_PROTOCOL:
        set_pre = preflight_extension_v2_restore_set(
            runtime_plan, manifest, databases=(database,), dumps={database: dump_path},
            container=container, command_runner=runner, policy=extension_restore_policy,
            require_quiescence=False, coordinated=False,
        )
        ext_planned = planned_pg_restore_command(runtime_plan, database, exit_on_error=True, use_list_path="<private-derived-toc>")
        ext_actions = ("preflight-extension-v2", "create-database", "install-extensions", "restore-dump-with-derived-toc", "reconcile-roles-and-grants", "verify-post-restore")
        if not dry_run:
            execute_extension_v2_restore_set(runtime_plan, set_pre, restore_order=(database,), command_runner=runner, coordinated=False)
        return LocalDbInitResult(
            command="init", result="dry_run" if dry_run else "success", repo_map_home=home, database=database, source_mode="dump",
            runtime_plan=runtime_plan, container=container, backup_id=optional_manifest_text(manifest.get("backup_id")),
            backup_path=manifest_path.parent, manifest_path=manifest_path, dump_file=dump_file["name"], dump_path=dump_path,
            checksum_verified=True, target_existed=False, planned_actions=ext_actions, planned_command=ext_planned,
            database_created=not dry_run, dump_restored=not dry_run, schema_ready=not dry_run,
        )
    verify_archive_toc_for_restore(
        runtime_plan,
        manifest,
        database=database,
        dump_path=dump_path,
        command_runner=runner,
        extension_restore_policy=extension_restore_policy,
    )
    exists_fn = database_exists
    existed = exists_fn(runtime_plan, database, runner)
    if existed:
        raise database_already_exists(database)
    planned = planned_pg_restore_command(runtime_plan, database)
    if dry_run:
        return LocalDbInitResult(
            command="init",
            result="dry_run",
            repo_map_home=home,
            database=database,
            source_mode="dump",
            runtime_plan=runtime_plan,
            container=container,
            backup_id=optional_manifest_text(manifest.get("backup_id")),
            backup_path=manifest_path.parent,
            manifest_path=manifest_path,
            dump_file=dump_file["name"],
            dump_path=dump_path,
            checksum_verified=True,
            target_existed=False,
            planned_actions=("create-database", "restore-dump"),
            planned_command=planned,
        )
    create_fn = create_database
    create_fn(runtime_plan, database, runner)

    restore_fn = run_pg_restore
    roles_fn = reconcile_graph_database_roles

    def provision_from_dump() -> None:
        restore_fn(runtime_plan, database, dump_path, planned, runner)
        reconcile_restored_graph_lexical_roles(runtime_plan, database, runner, roles_fn)

    complete_graph_provision(
        runtime_plan,
        database,
        runner,
        provision_from_dump,
    )
    return LocalDbInitResult(
        command="init",
        result="success",
        repo_map_home=home,
        database=database,
        source_mode="dump",
        runtime_plan=runtime_plan,
        container=container,
        backup_id=optional_manifest_text(manifest.get("backup_id")),
        backup_path=manifest_path.parent,
        manifest_path=manifest_path,
        dump_file=dump_file["name"],
        dump_path=dump_path,
        checksum_verified=True,
        target_existed=False,
        planned_actions=("create-database", "restore-dump"),
        planned_command=planned,
        database_created=True,
        dump_restored=True,
        schema_ready=True,
    )


def build_backup_plan(
    runtime_plan: LocalRuntimePlan,
    *,
    command: str,
    backup_kind: str,
    database: str | None,
    databases: tuple[str, ...],
    timestamp: str | None,
    reason: str | None,
) -> LocalDbBackupPlan:
    stamp = timestamp or timestamp_utc()
    safe_timestamp(stamp)
    runtime_id = runtime_plan.identity.home_hash
    if database:
        backup_id = f"{runtime_id}--{database}--{stamp}"
        path = backup_root(runtime_plan.repo_map_home) / runtime_id / database / stamp
    else:
        backup_id = f"{runtime_id}--all-databases--{stamp}"
        path = backup_root(runtime_plan.repo_map_home) / runtime_id / "all-databases" / stamp
    return LocalDbBackupPlan(
        command=command,
        plan=runtime_plan,
        backup_kind=backup_kind,
        timestamp=stamp,
        database=database,
        databases=databases,
        backup_id=backup_id,
        backup_path=path,
        dump_format="pgcustom",
        reason=bounded_text(reason) if reason else None,
        container_internal=container_internal_enabled(),
    )


def execute_backup_plan(
    backup_plan: LocalDbBackupPlan,
    *,
    database: str,
    command_runner: CommandRunner,
    container: RuntimeContainerMetadata,
    scope: str,
    extension_restore_policy: TrustedExtensionRestorePolicy | None = None,
) -> LocalDbBackupResult:
    planned_command = backup_plan.planned_dump_command(database)
    if backup_plan.backup_path.exists():
        ensure_new_backup_directory(backup_plan.backup_path)
    read_runtime_password(backup_plan.plan.env_file)
    with acquire_or_reuse_backup_maintenance_window(
        backup_plan.plan,
        (database,),
        command_runner=command_runner,
        require_window=True,
    ) as authority_namespace, atomic_private_backup_directory(
        backup_plan.backup_path,
        backups_root=backup_root(backup_plan.plan.repo_map_home),
    ) as staging_path:
        staging_plan = replace(backup_plan, backup_path=staging_path)
        before_obs = observe_database_provenance(
            backup_plan.plan, database, command_runner, extension_restore_policy=extension_restore_policy
        )
        dump_file = run_pg_dump(
            backup_plan.plan,
            planned_command,
            command_runner,
            staging_path / "dump.pgcustom",
        )
        after_obs = verify_provenance_fingerprints(
            before_obs,
            observe_database_provenance(
                backup_plan.plan, database, command_runner, extension_restore_policy=extension_restore_policy
            ),
        )
        toc_obs = observe_archive_toc(
            backup_plan.plan,
            database,
            staging_path / "dump.pgcustom",
            command_runner,
            after_obs.database_catalog,
        )
        quiescence = quiescence_record_for_databases(
            database,
            before_after_fingerprint_matched=True,
            authority_namespace=authority_namespace,
        )
        support = derive_manifest_support(
            {database: after_obs.database_catalog},
            before_after_fingerprint_matched=True,
            require_quiescence=(scope == "pre-drop-single-database"),
            quiescence=quiescence,
            extension_restore_policy=extension_restore_policy,
            server_provenance=after_obs.server_provenance,
        )
        write_manifest_and_restore_docs(
            staging_plan,
            dump_files=(dump_file,),
            container=container,
            command_invoked=planned_command,
            scope=scope,
            server_provenance=after_obs.server_provenance,
            database_catalogs={database: after_obs.database_catalog},
            toc_digests={dump_file.name: toc_obs.toc_sha256},
            quiescence=quiescence,
            support_evaluation=support,
            extension_restore_policy=extension_restore_policy,
        )
    return LocalDbBackupResult(
        command=backup_plan.command,
        result="success",
        plan=backup_plan,
        dump_files=(dump_file,),
        container=container,
        planned_command=planned_command,
        backup_path_created=True,
        dump_executed=True,
        restore_supported=support.restore_supported,
        restore_protocol=support.restore_protocol,
        restore_blockers=support.restore_blockers,
    )
